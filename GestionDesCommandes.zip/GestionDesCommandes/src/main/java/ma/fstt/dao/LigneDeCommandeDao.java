package ma.fstt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ma.fstt.conn.Point;
import ma.fstt.conn.SingletonConnection;
import ma.fstt.entities.LigneDeCommande;
import ma.fstt.service.LigneDeCommandeRepository;

public class LigneDeCommandeDao implements LigneDeCommandeRepository{

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public LigneDeCommandeDao() throws SQLException, ClassNotFoundException {
		connection = SingletonConnection.getConnection();
	}
	@Override
	public void AjouterLigneDeCommande(LigneDeCommande ligneDeCommande) {
		try {
			String qry = "insert into lignedecommande (quantite, idCommande, idProduit) values (?, ?, ?)";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setDouble(1, ligneDeCommande.getQuantite());
			this.preparedStatement.setInt(2, ligneDeCommande.getIdCommande());
			this.preparedStatement.setInt(3, ligneDeCommande.getIdProduit());
			this.preparedStatement.execute();
		}catch( SQLException e) { e.printStackTrace();}
	}

	@Override
	public void ModifierLigneDeCommande(LigneDeCommande ligneDeCommande) {
		
		try {
			String qry = "update lignedecommande set quantite = ?, idProduit = ? where idLigneDeCommande = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setDouble(1, ligneDeCommande.getQuantite());
			this.preparedStatement.setInt(2, ligneDeCommande.getIdProduit());
			this.preparedStatement.setInt(3, ligneDeCommande.getIdLigneDeCommande());
			this.preparedStatement.execute();
		}catch( SQLException e) { e.printStackTrace();	}
	}

	@Override
	public LigneDeCommande LireLigneDeCommande(int id) {
		String qry = "select * from lignedecommande where idLigneDeCommande = ?";
		LigneDeCommande ligneDeCommande = null;
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.resultSet = this.preparedStatement.executeQuery();
			while(this.resultSet.next()) {
				ligneDeCommande = new LigneDeCommande(this.resultSet.getInt(1), this.resultSet.getInt(2), this.resultSet.getInt(3), this.resultSet.getInt(4));
				break;
			}
		}catch( SQLException e) { e.printStackTrace();	}
 		return ligneDeCommande;
	}

	@Override
	public List<LigneDeCommande> LireLigneDeCommandes() {
		String qry = "select * from lignedecommande";
		List<LigneDeCommande> listldc = new ArrayList<LigneDeCommande>();
		try {
			this.statement = this.connection.createStatement();
			this.resultSet = this.statement.executeQuery(qry);
			while(this.resultSet.next()) {
				listldc.add(new LigneDeCommande(this.resultSet.getInt(1), this.resultSet.getInt(2), this.resultSet.getInt(3), this.resultSet.getInt(4)));
			}
		}catch( SQLException e) { e.printStackTrace();	}
		return listldc;
	}
	@Override
	public List<LigneDeCommande> LireLigneParCommande(int id) {
		String qry = "select * from lignedecommande where idCommande = ?";
		List<LigneDeCommande> listldc = new ArrayList<LigneDeCommande>();
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.resultSet = this.preparedStatement.executeQuery();
			while(this.resultSet.next()) {
				listldc.add(new LigneDeCommande(this.resultSet.getInt(1), this.resultSet.getInt(2), this.resultSet.getInt(3), this.resultSet.getInt(4)));
			}
		}catch( SQLException e) { e.printStackTrace();	}
		return listldc;
	}

	@Override
	public void SupprimerLigneDeCommande(int id) {
		try {
			String qry = "delete from lignedecommande where idLigneDeCommande = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.preparedStatement.execute();
		}catch( SQLException e) { e.printStackTrace();	}
	}
	@Override
	public void ModifierLCQuantite(int lcd, int idp, int qte) {
		
		try {
			String qry = "update lignedecommande set quantite = ?, idProduit = ? where idLigneDeCommande = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setDouble(1, qte);
			this.preparedStatement.setInt(2, idp);
			this.preparedStatement.setInt(3, lcd);
			this.preparedStatement.execute();
		}catch( SQLException e) { e.printStackTrace();	}
	}
	@Override
	public List<Point> QteCm() {
		
		String qry = "select distinct idProduit, sum(quantite) as somme from lignedecommande group by idProduit";
		List<Point> listp = new ArrayList<Point>();
		try {
			this.statement = this.connection.createStatement();
			this.resultSet = this.statement.executeQuery(qry);
			while(this.resultSet.next()) {
				listp.add(new Point(this.resultSet.getInt(1), this.resultSet.getInt(2) ));
			}
		}catch( SQLException e) { e.printStackTrace();	}
		return listp;
		 	}
	
}
