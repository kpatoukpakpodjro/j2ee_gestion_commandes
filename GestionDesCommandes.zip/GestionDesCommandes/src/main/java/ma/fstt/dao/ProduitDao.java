package ma.fstt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ma.fstt.conn.SingletonConnection;
import ma.fstt.entities.Produit;
import ma.fstt.service.ProduitRepository;

public class ProduitDao implements ProduitRepository{

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public ProduitDao() throws SQLException, ClassNotFoundException {
		connection = SingletonConnection.getConnection();
	}
	@Override
	public void AjouterProduit(Produit produit) {
 
		try {
			String qry = "insert into produit (nomProduit, prixProdui) values (?, ?)";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setString(1, produit.getNomProduit());
			this.preparedStatement.setDouble(2, produit.getPrixProduit());
			this.preparedStatement.execute();
		}catch( SQLException e) { e.printStackTrace();}
	}

	@Override
	public void ModifierProduit(Produit produit) {

		try {
			String qry = "update produit set nomProduit = ?, prixProduit = ? where idProduit = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setString(1, produit.getNomProduit());
			this.preparedStatement.setDouble(2, produit.getPrixProduit());
			this.preparedStatement.setInt(3, produit.getIdProduit());
			this.preparedStatement.execute();
		
		}catch( SQLException e) { e.printStackTrace();}
	}

	@Override
	public Produit LireProduit(int id) {
		String qry = "select * from produit where idProduit = ?";
		Produit produit = null;
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.resultSet = this.preparedStatement.executeQuery();
			while(this.resultSet.next()) {
				produit = new Produit(this.resultSet.getInt(1), this.resultSet.getString(2), this.resultSet.getDouble(3));
				break;
			}
		
		}catch( SQLException e) { e.printStackTrace();}
		return produit;
	}
	@Override
	public Produit LireProduit(String nomP) {
		String qry = "select * from produit where nomProduit = ?";
		Produit produit = null;
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setString(1, nomP);
			this.resultSet = this.preparedStatement.executeQuery();
			while(this.resultSet.next()) {
				produit = new Produit(this.resultSet.getInt(1), this.resultSet.getString(2), this.resultSet.getDouble(3));
				break;
			}
		
		}catch( SQLException e) { e.printStackTrace();}
		return produit;
	}

	@Override
	public List<Produit> LireProduits() {
		String qry = "select * from produit";
		List<Produit> listprod = new ArrayList<Produit>();	
		try {
			this.statement = this.connection.createStatement();
			this.resultSet = this.statement.executeQuery(qry);
			while(this.resultSet.next()) {
				listprod.add(new Produit(this.resultSet.getInt(1), this.resultSet.getString(2), this.resultSet.getDouble(3)));
			}
		
		}catch( SQLException e) { e.printStackTrace();}
		return listprod;
	}

	@Override
	public void SupprimerProduit(int id) {
		try {
			String qry = "delete from produit where idProduit = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.preparedStatement.execute();
		
		}catch( SQLException e) { e.printStackTrace();}
	}
}