package ma.fstt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ma.fstt.conn.SingletonConnection;
import ma.fstt.entities.Client;
import ma.fstt.service.ClientRepository;

public class ClientDao implements ClientRepository {
	private Connection connection ;//=SingletonConnection.getConnection();
	private Statement statement;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	public ClientDao() throws SQLException, ClassNotFoundException {
		connection = SingletonConnection.getConnection();
	}
	@Override
	public void AjouterClient(Client client)  {
		String qry = "insert into client (nomClient, passwordClient, adresseClient, emailClient) values ( ?, ?, ?, ?)";
		try {
			this.preparedStatement = connection.prepareStatement(qry);
			this.preparedStatement.setString(1, client.getNomClient());
			this.preparedStatement.setString(2, client.getPasswordClient());
			this.preparedStatement.setString(3, client.getAdresseClient());
			this.preparedStatement.setString(4, client.getEmailClient());
			this.preparedStatement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ModifierClient(Client client) {
		String qry = "update client set nomClient = ?, passwordClient = ?, adresseClient = ? , emailClient = ? where idClient=?";
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setString(1, client.getNomClient());
			this.preparedStatement.setString(2, client.getPasswordClient());
			this.preparedStatement.setString(3, client.getAdresseClient());
			this.preparedStatement.setString(4, client.getEmailClient());
			this.preparedStatement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Client LireClient(int id) {
		String qry = "select * from client where idClient = ?";
		Client client = null;
		
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.resultSet = this.preparedStatement.executeQuery();
			while (this.resultSet.next()) {
				client = new Client(this.resultSet.getInt(1), this.resultSet.getString(2), this.resultSet.getString(3), this.resultSet.getString(4), 
						this.resultSet.getString(5));
				break;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return client;
	}

	@Override
	public List<Client> LireClients() {
		String qry = "select * from client";
		List<Client> listcl = new ArrayList<Client>();
		try {
			this.statement = this.connection.createStatement();
			this.resultSet = this.statement.executeQuery(qry);
			while (this.resultSet.next()) {
				listcl.add(new Client(this.resultSet.getInt(1), this.resultSet.getString(2), 
						this.resultSet.getString(3), this.resultSet.getString(4), 
						this.resultSet.getString(5)));
			}
		}
		catch (SQLException e) {
				e.printStackTrace();
			}
		return listcl;
	}
	@Override
	public void SupprimerClient(int id) {
		String qry = "delete from client where idClient = ?";
		try {
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.preparedStatement.execute();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}