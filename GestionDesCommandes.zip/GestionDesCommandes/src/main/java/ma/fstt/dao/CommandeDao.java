package ma.fstt.dao;
import ma.fstt.conn.SingletonConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ma.fstt.entities.Commande;
import ma.fstt.service.CommandeRepository;
public class CommandeDao implements CommandeRepository{

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public CommandeDao() throws SQLException, ClassNotFoundException {
		connection = SingletonConnection.getConnection();
	}
	
	@Override
	public void AjouterCommande(Commande commande) {

		try {
			String qry = "insert into commande (dateCommande, idClient) values (?, ?)";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setDate(1, commande.getDateCommande());
			this.preparedStatement.setInt(2, commande.getIdClient());
			this.preparedStatement.execute();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ModifierCommande(Commande commande) {
		
		try{
			String qry = "update commande set dateCommande = ? where idCommande = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setDate(1, commande.getDateCommande());
			this.preparedStatement.setInt(2, commande.getIdCommande());
			this.preparedStatement.execute();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Commande LireCommande(int id) {
		String qry = "select * from commande where idCommande = ?";
		Commande commande = null;
		try{
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.resultSet = this.preparedStatement.executeQuery();
			while(this.resultSet.next()) {
				commande = new Commande(this.resultSet.getInt(1), this.resultSet.getDate(2), this.resultSet.getInt(3));
				break;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return commande;
	}

	@Override
	public List<Commande> LireCommandes() {
		String qry = "select * from commande";
		List<Commande> listcmd = new ArrayList<Commande>();
		try{
			this.statement = this.connection.createStatement();
			this.resultSet = this.statement.executeQuery(qry);
			while(this.resultSet.next()) {
				listcmd.add(new Commande(this.resultSet.getInt(1), this.resultSet.getDate(2), this.resultSet.getInt(3)));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return listcmd;
	}

	@Override
	public void SupprimerCommande(int id) {
		try {
			String qry = "delete from commande where idCommande = ?";
			this.preparedStatement = this.connection.prepareStatement(qry);
			this.preparedStatement.setInt(1, id);
			this.preparedStatement.execute();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Commande> LireCommandeClient(int id){
		String qry = "select * from commande where idClient = ?";
		List<Commande> list = new ArrayList<Commande>();
		try {
		this.preparedStatement = this.connection.prepareStatement(qry);
		this.preparedStatement.setInt(1, id);
		this.resultSet = this.preparedStatement.executeQuery();
		while(this.resultSet.next()) {
			list.add(new Commande(this.resultSet.getInt(1), this.resultSet.getDate(2), this.resultSet.getInt(3)));
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}