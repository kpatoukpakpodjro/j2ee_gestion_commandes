package ma.fstt.entities;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class LigneDeCommande {

	private int idLigneDeCommande;
	private int quantite;
	private int idCommande;
	private int idProduit;

	public LigneDeCommande() {
		super();
	}

	public LigneDeCommande(int idLigneDeCommande, int quantite, int idCommande, int idProduit) {
		super();
		this.idLigneDeCommande = idLigneDeCommande;
		this.quantite = quantite;
		this.idCommande = idCommande;
		this.idProduit = idProduit;
	}

	public int getIdLigneDeCommande() {
		return idLigneDeCommande;
	}

	public void setIdLigneDeCommande(int idLigneDeCommande) {
		this.idLigneDeCommande = idLigneDeCommande;
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}

	public int getIdCommande() {
		return idCommande;
	}

	public void setIdCommande(int idCommande) {
		this.idCommande = idCommande;
	}

	public int getIdProduit() {
		return idProduit;
	}

	public void setIdProduit(int idProduit) {
		this.idProduit = idProduit;
	}

	@Override
	public String toString() {
		return "LigneDeCommande [idLigneDeCommande=" + idLigneDeCommande + ", quantite=" + quantite + ", idCommande="
				+ idCommande + ", idProduit=" + idProduit + "]";
	}
	
}