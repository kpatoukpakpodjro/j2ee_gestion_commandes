package ma.fstt.entities;

import java.sql.Date;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class Commande {

	private int idCommande;
	private Date dateCommande;
	private int idClient;

	public Commande() {
		super();
	}

	public Commande(int idCommande, Date dateCommande, int idClient) {
		super();
		this.idCommande = idCommande;
		this.dateCommande = dateCommande;
		this.idClient = idClient;
	}

	public int getIdCommande() {
		return idCommande;
	}

	public void setIdCommande(int idCommande) {
		this.idCommande = idCommande;
	}

	public Date getDateCommande() {
		return dateCommande;
	}

	public void setDateCommande(Date dateCommande) {
		this.dateCommande = dateCommande;
	}

	public int getIdClient() {
		return idClient;
	}

	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}

	@Override
	public String toString() {
		return "Commande [idCommande=" + idCommande + ", dateCommande=" + dateCommande + ", idClient=" + idClient + "]";
	}
	
}