package ma.fstt.entities;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class Client {

	private int idClient;
	private String nomClient;
	private String passwordClient;
	private String adresseClient;
	private String emailClient;
	
	public Client () {
		super();
	}
	@Override
	public String toString() {
		return "Client [idClient=" + idClient + ", nomClient=" + nomClient + ", passwordClient=" + passwordClient
				+ ", adresseClient=" + adresseClient + ", emailClient=" + emailClient + "]";
	}
	public Client(int idClient, String nomClient, String passwordClient, String adresseClient, String emailClient) {
		super();
		this.idClient = idClient;
		this.nomClient = nomClient;
		this.passwordClient = passwordClient;
		this.adresseClient = adresseClient;
		this.emailClient = emailClient;
	}
	public int getIdClient() {
		return idClient;
	}
	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}
	public String getNomClient() {
		return nomClient;
	}
	public void setNomClient(String nomClient) {
		this.nomClient = nomClient;
	}
	public String getPasswordClient() {
		return passwordClient;
	}
	public void setPasswordClient(String passwordClient) {
		this.passwordClient = passwordClient;
	}
	public String getAdresseClient() {
		return adresseClient;
	}
	public void setAdresseClient(String adresseClient) {
		this.adresseClient = adresseClient;
	}
	public String getEmailClient() {
		return emailClient;
	}
	public void setEmailClient(String emailClient) {
		this.emailClient = emailClient;
	}
}