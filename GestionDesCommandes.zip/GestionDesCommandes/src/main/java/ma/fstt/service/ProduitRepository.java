package ma.fstt.service;

import java.util.List;

import ma.fstt.entities.Produit;

public interface ProduitRepository {

	public void AjouterProduit(Produit produit);
	public void ModifierProduit(Produit produit);
	public Produit LireProduit(int id);
	public List <Produit> LireProduits();
	public void SupprimerProduit(int id);
	public Produit LireProduit(String nomP);
}