package ma.fstt.service;

import java.util.List;

import ma.fstt.entities.Commande;

public interface CommandeRepository {

	public void AjouterCommande(Commande commande);
	public void ModifierCommande(Commande commande);
	public Commande LireCommande(int id);
	public List <Commande> LireCommandes();
	public List <Commande> LireCommandeClient(int id);
	public void SupprimerCommande(int id);
}