package ma.fstt.service;

import java.util.List;

import ma.fstt.entities.Client;

public interface ClientRepository {

	public void AjouterClient(Client client);
	public void ModifierClient(Client client);
	public Client LireClient(int id);
	public List <Client> LireClients();
	public void SupprimerClient(int id);
}