package ma.fstt.service;

import java.util.List;

import ma.fstt.conn.Point;
import ma.fstt.entities.LigneDeCommande;

public interface LigneDeCommandeRepository {

	public void AjouterLigneDeCommande(LigneDeCommande ligneDeCommande);
	public void ModifierLigneDeCommande(LigneDeCommande ligneDeCommande);
	public LigneDeCommande LireLigneDeCommande(int id);
	public List <LigneDeCommande> LireLigneDeCommandes();
	public void SupprimerLigneDeCommande(int id);
	public List<LigneDeCommande> LireLigneParCommande(int id);
	public void ModifierLCQuantite(int idlc,int idp, int qte);
	public List<Point> QteCm ();
}