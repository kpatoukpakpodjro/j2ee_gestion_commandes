package ma.fstt.controller;

import java.io.IOException;
 import java.sql.SQLException;
 import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ma.fstt.dao.ProduitDao;
import ma.fstt.entities.Produit;

@WebServlet("/ProduitServlet")
public class ProduitServlet extends HttpServlet {
 	@Inject private ProduitDao produitDao;
 	
 	private static final long serialVersionUID = 1L;
    private int tmp;
	public ProduitServlet() {
        super();   
        try {
   			produitDao = new ProduitDao();
		} catch (ClassNotFoundException e) {
			System.out.println("erreur 1");
		} catch (SQLException e) {
			System.out.println("erreur 2");
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   // try {
		HttpSession session = request.getSession();
		
		List<Produit> listProduit = new ArrayList<Produit>();
 		Produit pr = new Produit();
 		// liste des produits
		if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 1)
		{
			listProduit = produitDao.LireProduits();
			request.setAttribute("listProduit", listProduit);
			session.setAttribute("listProduit", listProduit);
			this.getServletContext().getRequestDispatcher("/showProduits.jsp").forward(request, response);
		}
		// ajouter ou modifier un produit
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 2)
		{
			 
			int id;
			try{ id= Integer.parseInt(request.getParameter("idProduit"));
			}catch(Exception e) { id=tmp;}
			String nomProduit = request.getParameter("nomProduit");
			float prixProduit = Float.parseFloat(request.getParameter("prixProduit")) ;
			 pr = new Produit(id, nomProduit, prixProduit);
			if(tmp==1){
			produitDao.AjouterProduit(pr);}
			else {
				produitDao.ModifierProduit(pr);
			}
			session.setAttribute("produit", pr);
			listProduit = produitDao.LireProduits();
			request.setAttribute("listProduit", listProduit);
			this.getServletContext().getRequestDispatcher("/showProduits.jsp").forward(request, response);
 		}
		// Modification
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 3)
		{
			 
			int id  = Integer.parseInt(request.getParameter("idProdui"));
			String nomProduit = request.getParameter("nomProduit");
			float prixProduit = Float.parseFloat(request.getParameter("prixProduit")) ;
			 pr = new Produit(id, nomProduit, prixProduit);
			
			produitDao.ModifierProduit(pr);
			listProduit = produitDao.LireProduits();
			request.setAttribute("listProduit", listProduit);
			this.getServletContext().getRequestDispatcher("/showProduits.jsp").forward(request, response);
 		}
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 4)
		{
			int id  = Integer.parseInt(request.getParameter("idProdui"));
 			produitDao.SupprimerProduit(id);
			listProduit = produitDao.LireProduits();
			request.setAttribute("listProduit", listProduit);
			session.setAttribute("listProduit", listProduit);
			this.getServletContext().getRequestDispatcher("/showProduits.jsp").forward(request, response);
		}
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 9)
		{
			tmp=1;
			if(request.getParameter("idProduit")!=null) {
				this.tmp= Integer.parseInt(request.getParameter("idProduit"));
				request.setAttribute("produit", produitDao.LireProduit(tmp));
			}
 			this.getServletContext().getRequestDispatcher("/creerProduit.jsp").forward(request, response);
		}
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
