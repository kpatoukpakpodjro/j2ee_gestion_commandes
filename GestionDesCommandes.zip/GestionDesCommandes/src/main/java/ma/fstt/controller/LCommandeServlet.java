package ma.fstt.controller;

import java.io.IOException;
 import java.sql.SQLException;
 import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ma.fstt.conn.Point;
 import ma.fstt.dao.LigneDeCommandeDao;
 import ma.fstt.entities.LigneDeCommande;
 
@WebServlet("/LCommandeServlet")
public class LCommandeServlet extends HttpServlet {
 	@Inject private LigneDeCommandeDao ligneDeCommandeDao;
	private static final long serialVersionUID = 1L;
    private int tmp;
	public LCommandeServlet() {
        super();   
        try {
 			ligneDeCommandeDao  = new LigneDeCommandeDao();
 		} catch (ClassNotFoundException e) {
			System.out.println("erreur 1");
		} catch (SQLException e) {
			System.out.println("erreur 2");
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   // try {
		HttpSession session = request.getSession();
		
		List<LigneDeCommande> listLCommande = new ArrayList<LigneDeCommande>();
		List<Point> listCC = new ArrayList<Point>();
		LigneDeCommande ld ;//= new LigneDeCommande();
 		// liste des clients
		if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 1)
		{
			listLCommande= ligneDeCommandeDao.LireLigneDeCommandes();
			request.setAttribute("listLCommande", listLCommande);
			session.setAttribute("listLCommande", listLCommande);
			this.getServletContext().getRequestDispatcher("/showLCommandes.jsp").forward(request, response);
		}
		// ajouter une ligne de commande
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 2)
		{
			int id;
			try {
			id  = Integer.parseInt(request.getParameter("idLigneDeCommande"));
			}catch(Exception e) { id=tmp;}
			int idp  = Integer.parseInt(request.getParameter("idProduit"));			 
			int idc  = Integer.parseInt(request.getParameter("idCommande"));
			int qte  = Integer.parseInt(request.getParameter("quantite"));
			ld = new LigneDeCommande(id,qte,idc,idp);
			if(tmp==1) {
			ligneDeCommandeDao.AjouterLigneDeCommande(ld);}
			else {
				ligneDeCommandeDao.ModifierLigneDeCommande(ld);
			}
			listLCommande= ligneDeCommandeDao.LireLigneDeCommandes();
			request.setAttribute("listLCommande", listLCommande);
			session.setAttribute("listLCommande", listLCommande);
			this.getServletContext().getRequestDispatcher("/showLCommandes.jsp").forward(request, response);
 		}
		// Modification
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 3)
		{
			 
			int id  = Integer.parseInt(request.getParameter("idLCommande"));
			int idp  = Integer.parseInt(request.getParameter("idProduit"));			 
 			int qte  = Integer.parseInt(request.getParameter("quantite"));
 			ligneDeCommandeDao.ModifierLCQuantite(id, idp, qte);
 			listLCommande= ligneDeCommandeDao.LireLigneDeCommandes();
			request.setAttribute("listLCommande", listLCommande);
			session.setAttribute("listLCommande", listLCommande);
			this.getServletContext().getRequestDispatcher("/showLCommandes.jsp").forward(request, response);
 		}
		//supprimer la ligne
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 4)
		{
			int id  = Integer.parseInt(request.getParameter("idLCommande")); // Id de l'�l�ment � supprimer
			ligneDeCommandeDao.SupprimerLigneDeCommande(id);

			listLCommande= ligneDeCommandeDao.LireLigneDeCommandes();
			request.setAttribute("listLCommande", listLCommande);
			session.setAttribute("listLCommande", listLCommande);
			this.getServletContext().getRequestDispatcher("/showLCommandes.jsp").forward(request, response);
		}
		// nb de  commandes pass�es par chaque client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 5)
		{
			 listCC=ligneDeCommandeDao.QteCm();
			 request.setAttribute("listLCommande", listCC);
			this.getServletContext().getRequestDispatcher("/showCommandebyPro.jsp").forward(request, response);
		}
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 9)
		{
			tmp=1;
			if(request.getParameter("idLigneDeCommande")!=null) {
			 this.tmp  = Integer.parseInt(request.getParameter("idLigneDeCommande"));
			 request.setAttribute("ligneDeCommande", ligneDeCommandeDao.LireLigneDeCommande(tmp));
			}
			this.getServletContext().getRequestDispatcher("/creerLC.jsp").forward(request, response);
		}
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
