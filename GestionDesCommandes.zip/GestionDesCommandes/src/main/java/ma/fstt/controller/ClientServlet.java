package ma.fstt.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ma.fstt.dao.ClientDao;
import ma.fstt.dao.CommandeDao;
import ma.fstt.dao.LigneDeCommandeDao;
import ma.fstt.dao.ProduitDao;
import ma.fstt.entities.Client;
import ma.fstt.entities.Commande;
import ma.fstt.entities.LigneDeCommande;
import ma.fstt.entities.Produit;

@WebServlet("/ClientServlet")
public class ClientServlet extends HttpServlet {
	@Inject private ClientDao clientDao;
	@Inject private CommandeDao commandeDao;
	@Inject private ProduitDao produitDao;
	@Inject private LigneDeCommandeDao ligneDeCommandeDao;
	private static final long serialVersionUID = 1L;
    private int tmp;
	public ClientServlet() {
        super();   
        try {
			clientDao = new ClientDao();
			commandeDao = new CommandeDao();
			ligneDeCommandeDao  = new LigneDeCommandeDao();
			produitDao = new ProduitDao();
		} catch (ClassNotFoundException e) {
			System.out.println("erreur 1");
		} catch (SQLException e) {
			System.out.println("erreur 2");
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   // try {
		HttpSession session = request.getSession();
		
		List<Commande> listCommande = new ArrayList<Commande>();
		List<Client> listClient = new ArrayList<Client>();
		LigneDeCommande ld ;//= new LigneDeCommande();
		Produit pr = new Produit();
		 Commande cd = new Commande();
		// liste des clients
		if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 1)
		{
			listClient = clientDao.LireClients();
			request.setAttribute("listClient", listClient);
			session.setAttribute("listClient", listClient);
			this.getServletContext().getRequestDispatcher("/showClients.jsp").forward(request, response);
		}
		// ajouter un client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 2)
		{    
			int id;
			 try {
			  id  = Integer.parseInt(request.getParameter("idClient"));
			 }catch(Exception e) { id=tmp;} 
			String nomClient = request.getParameter("nomClient");
			String passwordClient = request.getParameter("passwordClient");
			String adresseClient = request.getParameter("adresseClient");
			String emailClient = request.getParameter("emailClient");
			Client client1 = new Client(id, nomClient, passwordClient, adresseClient, emailClient);
			if(tmp==1){
				clientDao.AjouterClient(client1);
				}
			else {
				clientDao.ModifierClient(client1);}
			session.setAttribute("client", client1);
			listClient = clientDao.LireClients();
			request.setAttribute("listClient", listClient);
			this.getServletContext().getRequestDispatcher("/showClients.jsp").forward(request, response);
			//this.getServletContext().getRequestDispatcher("/home.jsp").forward(request, response);		
		}
		// Modification
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 3)
		{
			 
 			listCommande = commandeDao.LireCommandes();
			request.setAttribute("listCommande", listCommande);
			this.getServletContext().getRequestDispatcher("/showCommandes.jsp").forward(request, response);	
		}
		//supprimer un client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 4)
		{
			int id  = Integer.parseInt(request.getParameter("idClient")); // Id de l'�l�ment � supprimer
			clientDao.SupprimerClient(id);
			request.setAttribute("listClient", listClient);
			this.getServletContext().getRequestDispatcher("/ShowClients").forward(request, response);
		}
		// les commandes pass�es par le client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 5)
		{
			int id  = Integer.parseInt(request.getParameter("idClient"));
			listCommande = commandeDao.LireCommandeClient(id);
			request.setAttribute("listCommande", listCommande);
			this.getServletContext().getRequestDispatcher("/showCommandes.jsp").forward(request, response);
		}
		// supprimer une commande du client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 6)
		{
			int id  = Integer.parseInt(request.getParameter("idCommande"));
			commandeDao.SupprimerCommande(id);
			listCommande = commandeDao.LireCommandeClient(id);
			request.setAttribute("listCommande", listCommande);
			this.getServletContext().getRequestDispatcher("/showCommandes.jsp").forward(request, response);
		}
		// ajouter une commande aux commandes du client
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 7)
		{
			String cmdD = (String) request.getParameter("dateCommande");
			String cmdP = (String) request.getParameter("nomProduit");
			int cmdQ =Integer.parseInt((String) request.getParameter("quantite"));
			DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			pr=produitDao.LireProduit(cmdP);
			try {
				java.util.Date dateObject = sdf.parse(cmdD);
				//cd = new Commande(0, new Date( dateObject.getTime()), tmp);
				 commandeDao.AjouterCommande(cd);
			} catch (ParseException e) {
 				e.printStackTrace();
			}  
			listCommande = commandeDao.LireCommandes();
  			ld = new LigneDeCommande(1,cmdQ,listCommande.size(),pr.getIdProduit());
			ligneDeCommandeDao.AjouterLigneDeCommande(ld);
			listCommande = commandeDao.LireCommandeClient(tmp);
			request.setAttribute("listCommande", listCommande);
			this.getServletContext().getRequestDispatcher("/showCommandes.jsp").forward(request, response);
		}
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 8)
		{
			 tmp  = Integer.parseInt(request.getParameter("idClient"));
			this.getServletContext().getRequestDispatcher("/creerCommande.jsp").forward(request, response);
		}
		else if(request.getParameter("act") != null && Integer.parseInt(request.getParameter("act")) == 9)
		{
			tmp=1;
			if(request.getParameter("idClient")!=null) {
				this.tmp= Integer.parseInt(request.getParameter("idClient"));
				request.setAttribute("client", clientDao.LireClient(tmp));
			}
 			this.getServletContext().getRequestDispatcher("/creerClient.jsp").forward(request, response);
		}
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
