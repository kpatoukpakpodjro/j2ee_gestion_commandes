use db_commande;


-- création de la table client
CREATE TABLE client (
  idClient int primary key auto_increment ,
  nomClient varchar(255) DEFAULT NULL,
  passwordClient varchar(255) DEFAULT NULL,
  adresseClient varchar(255) DEFAULT NULL,
  emailClient varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertion de premières données

INSERT INTO client (nomClient,passwordClient,adresseClient,emailClient) VALUES
( 'kpatoukpa', '1231', 'Rabat', 'kkpatoukpa@gmail.com'),
( 'kpodjro', '1232', 'Tanger', 'kpodjro@gmail.com'),
( 'lsi2', '1234', 'Boukhalef, Tanger', 'fsttlsi@gmail.com');


CREATE TABLE commande (
  idCommande int primary key auto_increment,
  dateCommande DATE ,
  idClient int,
  FOREIGN KEY (idClient) REFERENCES Client (`IdClient`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- création de la table Produit

CREATE TABLE produit (
  idProduit int  primary key auto_increment,
  nomProduit varchar(255) DEFAULT NULL,
  prixProduit double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- création de la table lignedecommande

CREATE TABLE lignedecommande (
  idLigneDeCommande int primary key auto_increment,
  quantite int NOT NULL,
  idCommande int ,
  idProduit int ,
  FOREIGN KEY (idCommande) REFERENCES Commande (`IdCommande`) ON DELETE CASCADE,
  FOREIGN KEY (idProduit) REFERENCES Produit (`idProduit`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

 select * from client;
 
 INSERT INTO produit ( nomProduit, prixProduit) VALUES
 ('chauffage',280),
 ('pull',250),
 ('canape',400),
( 'T-shirt', 129),
( 'Scarf', 102),
( 'Jeans', 250),
( 'Dress', 249),
( 'Souris', 120);

select * from produit;

select * from lignedecommande;

insert into lignedecommande(  idProduit, idCommande, quantite) values
(  3,12,3), (6,13,7),(3,10,7),(6,8,20),(1,7,5);

delete  from lignedecommande where idProduit=6;

select * from commande;  -- where idCommande =11;

alter table db_commande.lignedecommande
  DROP FOREIGN KEY fk_idProduit;

SET  FOREIGN_KEY_CHECKS = 1;

ALTER TABLE lignedecommande 
DROP INDEX idProduit ;


select distinct idProduit, sum(quantite) as somme from lignedecommande
group by idProduit;